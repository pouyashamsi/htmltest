﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace proje
{
    class dbclass
    {
        private string cstring= "Data Source=(LocalDB)\\MSSQLLocalDB;AttachDbFilename='|DataDirectory|\\Database1.mdf';Integrated Security = True";
        private SqlConnection conn;
        private SqlCommand cmd;
        private SqlDataReader dr;
        private DataTable dt;
        public DataTable showview()
        {
            conn = new SqlConnection(cstring);
            string sqlstr = "select * from games";
            conn.Open();
            cmd = new SqlCommand(sqlstr, conn);
            dr = cmd.ExecuteReader();
            dt = new DataTable();
            dt.Load(dr);
            conn.Close();
            return dt;
            
        }
    }
}
