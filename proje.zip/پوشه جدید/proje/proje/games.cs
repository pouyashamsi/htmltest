﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace proje
{
    class games
    {
        private int _sid;
        private string _game;
        private string _emtiaz;
        private string _toolid;
        private string _sabk;
        public games(int sid,string game,string emtiaz,string toolid,string sabk)
        {
            this._sid = sid;
            this._game = game;
            this._emtiaz = emtiaz;
            this._toolid = toolid;
            this._sabk = sabk;
        }
        public bool register(List<course> ls)
        {
            bool isreg = true;
            //...
            return isreg;
        }
    }
}
