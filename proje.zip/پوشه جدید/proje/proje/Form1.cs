﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace proje
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void showallgames_Click(object sender, EventArgs e)
        {
            dbclass ob = new dbclass();
            DataTable dt;
            dt=ob.showview();
            dt.Columns[0].ColumnName = "شماره";
            dataGridView1.DataSource = dt;
        }
    }
}
